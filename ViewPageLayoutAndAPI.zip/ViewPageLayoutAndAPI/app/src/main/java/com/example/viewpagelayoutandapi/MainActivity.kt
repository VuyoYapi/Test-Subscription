package com.example.viewpagelayoutandapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager

class MainActivity : AppCompatActivity() {
    lateinit var frag: MainFrag
    lateinit var fragManager :FragmentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        frag = MainFrag()
        fragManager = supportFragmentManager
        val fragTrans = fragManager.beginTransaction()
        fragTrans.replace(R.id.frameLayout, frag)
        fragTrans.commit()

        fragManager.executePendingTransactions()
    }
}