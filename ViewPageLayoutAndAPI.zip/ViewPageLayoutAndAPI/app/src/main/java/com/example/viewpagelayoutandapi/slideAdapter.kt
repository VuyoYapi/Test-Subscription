package com.example.viewpagelayoutandapi

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class slideAdapter(val frag:Fragment) : FragmentStateAdapter(frag) {
    override fun getItemCount(): Int {
        return 3

    }

    override fun createFragment(position: Int): Fragment {
        val fragment = Screenslide()

        fragment.arguments = Bundle().apply {
            putInt("object",position+1)
        }
        return fragment

    }
}